const db = require('./db');

module.exports = {
    token_url: 'https://api.amazon.com/auth/o2/token',
    us_ad_url: 'https://advertising-api.amazon.com',
    ad_url: 'https://advertising-api-eu.amazon.com',
    access_token: '',
    metricsForAds: 'campaignId,campaignName,adGroupId,adGroupName,sku,currency,asin,impressions,clicks,cost,attributedConversions1d,attributedConversions7d,attributedConversions14d,attributedConversions30d,attributedConversions1dSameSKU,attributedConversions7dSameSKU,attributedConversions14dSameSKU,attributedConversions30dSameSKU,attributedUnitsOrdered1d,attributedUnitsOrdered7d,attributedUnitsOrdered14d,attributedUnitsOrdered30d,attributedSales1d,attributedSales7d,attributedSales14d,attributedSales30d,attributedSales1dSameSKU,attributedSales7dSameSKU,attributedSales14dSameSKU,attributedSales30dSameSKU',
    metricsForKeywords: 'campaignId,campaignName,keywordText,matchType,attributedConversions1d,attributedConversions1dSameSKU,impressions,clicks,cost,attributedConversions1d,attributedConversions7d,attributedConversions14d,attributedConversions30d,attributedConversions1dSameSKU,attributedConversions7dSameSKU,attributedConversions14dSameSKU,attributedConversions30dSameSKU,attributedUnitsOrdered1d,attributedUnitsOrdered7d,attributedUnitsOrdered14d,attributedUnitsOrdered30d,attributedSales1d,attributedSales7d,attributedSales14d,attributedSales30d,attributedSales1dSameSKU,attributedSales7dSameSKU,attributedSales14dSameSKU,attributedSales30dSameSKU',
    metricsForCampaigns: 'bidPlus,campaignName,campaignId,campaignStatus,campaignBudget,impressions,clicks,cost,attributedConversions1d,attributedConversions7d,attributedConversions14d,attributedConversions30d,attributedConversions1dSameSKU,attributedConversions7dSameSKU,attributedConversions14dSameSKU,attributedConversions30dSameSKU,attributedUnitsOrdered1d,attributedUnitsOrdered7d,attributedUnitsOrdered14d,attributedUnitsOrdered30d,attributedSales1d,attributedSales7d,attributedSales14d,attributedSales30d,attributedSales1dSameSKU,attributedSales7dSameSKU,attributedSales14dSameSKU,attributedSales30dSameSKU',   
    metricsForHSAKeywords: 'campaignId,campaignName,adGroupId,adGroupName,campaignBudget,campaignStatus,impressions,clicks,cost,keywordText,matchType,attributedConversions1d,attributedConversions7d,attributedConversions14d,attributedConversions30d,attributedConversions1dSameSKU,attributedConversions7dSameSKU,attributedConversions14dSameSKU,attributedConversions30dSameSKU,attributedUnitsOrdered1d,attributedUnitsOrdered7d,attributedUnitsOrdered14d,attributedUnitsOrdered30d,attributedSales1d,attributedSales7d,attributedSales14d,attributedSales30d,attributedSales1dSameSKU,attributedSales7dSameSKU,attributedSales14dSameSKU,attributedSales30dSameSKU',
    // The type of entity for which the report should be generated. This must be one of: campaigns, adGroups, keywords, productAds, or asins
    reportTypes: [
        'productAds', 'keywords', 'adGroups', 'campaigns'
    ],
    reportTypeForAds: 'productAds',
    reportTypeForKeywords: 'keywords',
    // The type of campaign for which performance data should be generated. Must be: sponsoredProducts or headlineSearch
    campaignType : 'sponsoredProducts', // headlineSearch
    campaignTypes: [
        'sponsoredProducts',     'headlineSearch'
    ],
    redirect_uri: 'https://',
    host : '',
    client_id : 'amzn1.application-oa2-client.ed236f4ff11f4616a4f483dbd5256c50',
    client_secret : '9aae8c8f4cf77994c84b6697d32d183fe5def95dcbb8b46001b0f0f3bdbabcb2',
    refresh_token: 'Atzr|IwEBIG_77l5m-imW3_M0P2Cu5XpgoaNzI4O72Ub0dEjQPhvsuf54Ee7vSU06mz4eaDKe5trgyUMw47eS9FNugM_5_bpvjCo6tsnl2gtYP2fsESTgInioy4KNwMmKshi6lYB4wGCzviVFtmBbAzbM5e8nfqFL9QORwPigoC8gXCZZS5Gs64hcgjdzfCG7NRpPXxk_nJfKgIzntoxnVLt98mfC-0y7LYnu5s4UXr5vfcffPHcteQo7rxkvCDpMo0D1b1WdOxU4n7wiNglHqyNMKrNZ6R29lzPmpfm5Q-Y3IE-3n8WEKmfDuqIRTbK8wlX2y6lu34JYJU5O37lhS4qAzV_Ukx1EA_dYR7tM-Ckd7lANp7aqcbCo7z4iO5ntEwGG27bOCxQMrt-FzSAQo5dJbaJK8yQkg8rKOrgplNsBzE1wLWfuIRgbmxD02jjde92dxLowRWpRKZwuIu08y9R8Zlmgbb6wZqrWUy6udbKHDP8vzjfPJFWrvyS-DucJlK_vnZPJU27_RpbvPEXcy81X70l6P6SRZRi-FkQo7hexVd1PCzg4yAmyPEg2AZSsbOi_CtkLDejP4LcPyzjVwIfFDqGWcqVO',

    token_type: 'bearer',
    db: db
}
