module.exports = {
    host: "51.15.243.42",
    user: "scaleway_admin",
    password: "mtROYqfVWz",
    database: "advertising_reports"
};  